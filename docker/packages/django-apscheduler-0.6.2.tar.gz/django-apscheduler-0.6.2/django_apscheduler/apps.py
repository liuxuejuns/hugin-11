from django.apps import AppConfig


class DjangoApschedulerConfig(AppConfig):
    name = "django_apscheduler"
    verbose_name = "Django APScheduler"
